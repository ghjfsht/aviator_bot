def get_latest_crash():
    # Demo: So‘nggi 10 ta random natija (real scraping o‘rnida)
    return [1.23, 1.55, 2.65, 1.77, 3.12, 0.9, 1.8, 2.25, 1.95, 2.85]
