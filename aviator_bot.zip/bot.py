from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from scraper import get_latest_crash
from analyzer import analyze_rounds
import os

TOKEN = os.getenv("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Salom! Aviator signal botiga xush kelibsiz.\n/analiz buyrug‘ini yozing.")

async def analiz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rounds = get_latest_crash()
    msg = analyze_rounds(rounds)
    await update.message.reply_text(msg)

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("analiz", analiz))

app.run_polling()
