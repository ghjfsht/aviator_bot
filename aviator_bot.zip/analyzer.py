def analyze_rounds(rounds):
    count_2x = sum(1 for x in rounds if x >= 2.0)
    since_last_2x = len(rounds) - next((i for i, x in enumerate(reversed(rounds)) if x >= 2.0), len(rounds))

    message = f"So‘nggi {len(rounds)} raund:\n"
    message += f"• 2x+ chiqishlar: {count_2x}\n"
    message += f"• Oxirgi 2x: {since_last_2x} raund oldin\n"

    if since_last_2x >= 3:
        message += "🔔 Ehtimoliy 2x yaqinlashmoqda!"
    else:
        message += "🔍 Hali 2x chiqmaganiga ko‘p bo‘lmadi."

    return message
